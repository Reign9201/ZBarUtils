  (int)(long)&((struct stringpool_t *)0)->stringpool_str112,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str491,
